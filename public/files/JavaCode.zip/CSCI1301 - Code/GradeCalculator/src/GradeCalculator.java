/*
 * GradeCalculator.java
 * Author:  John James
 * Submission Date:  2/20/23
 *
 * Purpose: This program takes the user input of their desired grade,
 * the grading weights for each of the assignments, and their scores 
 * (if known) and determines whether or not it is possible for the user
 * to obtain a certain grade. If it is possible, then it will compute
 * the necessary average for the remaining assignments needed to reach
 * the desired grade.
 *
 * Statement of Academic Honesty: This program takes the user input
 * of their grading weights and their averages (if known), calculates their
 * grade average, and determines whether or not their desired letter grade 
 * is achievable.
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this project is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class GradeCalculator {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		String desiredLetterGrade;
		String knowledgeOfGrade;
		int finalOverallScore = 0;
		double totalKnownGradeWeight, weightExam1, scoreExam1 = 0, weightExam2, scoreExam2 = 0, weightFinalExam, scoreFinalExam = 0, weightLabs, scoreLabs = 0, weightProjects, scoreProjects = 0, weightParticipation, scoreParticipation = 0, weightQuizzes, scoreQuizzes = 0;
		double currentScore, avgToFinalLetterGrade;
		String currentLetterGrade = "A";
// This creates "keyboard" and declares all necessary variables.
		
		
/*
 * The below code prints the grading scale to the console
 * and prompts the user to enter their desired grade. The
 * desired grade must be either: "A" "B" "C" "D" or "F"
 * (ignoring case).
 */
		System.out.println("Grading Scale:");
		System.out.println("A\t90 - 100");
		System.out.println("B\t80 - 89");
		System.out.println("C\t70 - 79");
		System.out.println("D\t60 - 69");
		System.out.println("F\tbelow 60");
		System.out.print("What letter grade do you want to achieve for the course?");
		desiredLetterGrade = keyboard.next();
	
		if (!((desiredLetterGrade.equalsIgnoreCase("A")) || (desiredLetterGrade.equalsIgnoreCase("B")) || (desiredLetterGrade.equalsIgnoreCase("C")) || (desiredLetterGrade.equalsIgnoreCase("D")) || (desiredLetterGrade.equalsIgnoreCase("F"))))
		{		
			System.out.print("The input is invalid");
			System.exit(0);
		}
/*
 * The below code prompts the user to enter the percentage weights
 * for each assignment. They all must add to 100.
 */
		System.out.println("Enter percentage weights below");
		System.out.print("Exam 1:\t\t");
		weightExam1 = keyboard.nextInt();
		System.out.print("Exam 2:\t\t");
		weightExam2 = keyboard.nextInt();
		System.out.print("Final Exam:\t");
		weightFinalExam = keyboard.nextInt();
		System.out.print("Labs:\t\t");
		weightLabs = keyboard.nextInt();
		System.out.print("Projects:\t");
		weightProjects = keyboard.nextInt();
		System.out.print("Participation:\t");
		weightParticipation = keyboard.nextInt();
		System.out.print("Quizzes:\t");
		weightQuizzes = keyboard.nextInt();
		
		if ((weightExam1 + weightExam2 + weightFinalExam + weightLabs + weightProjects + weightQuizzes + weightParticipation) != 100)
		{	
			System.out.println("Weights don't add up to 100, program exiting...");
			System.exit(0);
		}
		
/* The below code asks the user if they know their score for each assignment.
 * If "yes" or "y" (ignoring case), it will ask them to enter the value. If they
 * do not know the score for an assignment, its weight will be set to 0 as
 * to not be included in future calculations.
 */
		System.out.print("Do you know your exam 1 score?");
		knowledgeOfGrade = keyboard.next();
		if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
		{	
			System.out.print("Score received on exam 1:");
			scoreExam1 = keyboard.nextDouble();
			System.out.print("Do you know your exam 2 score?");
			knowledgeOfGrade = keyboard.next();
		
			if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
			{	
				System.out.print("Score received on exam 2:");
				scoreExam2 = keyboard.nextDouble();
				System.out.print("Do you know your final exam score?");
				knowledgeOfGrade = keyboard.next();
					if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
					{	
						System.out.print("Score received on final exam:");
						scoreFinalExam = keyboard.nextDouble();
					} else 
						weightFinalExam = 0;
			} else {
				weightExam2 = 0;
				weightFinalExam = 0;
			}
		} else {
			weightExam1 = 0;
			weightExam2 = 0; 
			weightFinalExam = 0;
		}
			
		System.out.print("Do you know your lab average?");
		knowledgeOfGrade = keyboard.next();
		if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
		{
			System.out.print("Average lab grade:");
			scoreLabs = keyboard.nextDouble();
		} else
			weightLabs = 0;
			
			
		System.out.print("Do you know your project average?");
		knowledgeOfGrade = keyboard.next();
		if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
		{
			System.out.print("Average project grade:");
			scoreProjects = keyboard.nextDouble();
		} else
			weightProjects = 0;
		
		System.out.print("Do you know your participation average?");
		knowledgeOfGrade = keyboard.next();
		if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
		{
			System.out.print("Average participation grade:");
			scoreParticipation = keyboard.nextDouble();
		} else
			weightParticipation = 0;
		
		System.out.print("Do you know your quiz average?");
		knowledgeOfGrade = keyboard.next();
		if (knowledgeOfGrade.equalsIgnoreCase("y") || knowledgeOfGrade.equalsIgnoreCase("yes"))
		{
			System.out.print("Average quiz grade:");
			scoreQuizzes = keyboard.nextDouble();
		} else
			weightQuizzes = 0;
		
keyboard.close();
// The code below takes the user's input, and calculates their current grade.
totalKnownGradeWeight = (weightExam1 + weightExam2 + weightFinalExam + weightLabs + weightProjects + weightParticipation + weightQuizzes);
currentScore = ((weightExam1 * scoreExam1) + (weightExam2 * scoreExam2) + (weightFinalExam * scoreFinalExam) + (weightLabs * scoreLabs) + (weightProjects * scoreProjects) + (weightParticipation * scoreParticipation) + (weightQuizzes * scoreQuizzes))/totalKnownGradeWeight;
System.out.printf("Current grade score: %.2f", currentScore);
System.out.print("\n");

//The code below determines the users current letter grade and prints it to the console.
if ((currentScore >= 90) && (currentScore <= 100))
	currentLetterGrade = "A";
else if ((currentScore < 90) && (currentScore >= 80))
	currentLetterGrade = "B";
else if ((currentScore < 80) && (currentScore >= 70))
	currentLetterGrade = "C";
else if ((currentScore < 70) && (currentScore >= 60))
	currentLetterGrade = "D";
else if ((currentScore < 60))
	currentLetterGrade = "F";
else
{
	System.out.print("ERROR: Grade is bigger than 100, program exiting");
	System.exit(0);
}	

System.out.println("Your current letter grade:" + currentLetterGrade);

/* The code below goes through a conditional statement that uses variety of variables.
 * First, if the current letter grade is equal to the desired letter grade, and all grades are in,
 * Then it congratulates the user. If the two letter grades are different and all grades are in, then the program
 * says that the grade unachievable. Otherwise, it will calculate the necessary average of the remaining assignments.
 * needed to get the desired grade.
 * 
 */
if (desiredLetterGrade.equalsIgnoreCase(currentLetterGrade) && (totalKnownGradeWeight == 100))
	System.out.println("Congratulations! You received the " + desiredLetterGrade + " you wanted!");
else if (!(desiredLetterGrade.equalsIgnoreCase(currentLetterGrade)) && (totalKnownGradeWeight == 100))
	System.out.println("Unfortunately, a grade of " + desiredLetterGrade + " is not possible");
else {
	if (desiredLetterGrade.equalsIgnoreCase("A"))
		finalOverallScore = 90;
	else if (desiredLetterGrade.equalsIgnoreCase("B"))
		finalOverallScore = 80;
	else if (desiredLetterGrade.equalsIgnoreCase("C"))
		finalOverallScore = 70;
	else if (desiredLetterGrade.equalsIgnoreCase("D"))
		finalOverallScore = 60;

	avgToFinalLetterGrade = (100 * finalOverallScore - ((weightExam1 * scoreExam1) + (weightExam2 * scoreExam2) + (weightFinalExam * scoreFinalExam) + (weightLabs * scoreLabs) + (weightProjects * scoreProjects) + (weightParticipation * scoreParticipation) + (weightQuizzes * scoreQuizzes)))/(100 - totalKnownGradeWeight);

	if (avgToFinalLetterGrade > 100)
		System.out.println("Unfortunately, a grade of " + desiredLetterGrade + " is not possible");
	else if (avgToFinalLetterGrade <= -100)
		System.out.print("You will receive atleast a grade of " + desiredLetterGrade + ".");
	else {
		System.out.println("In order to receive a grade of " + desiredLetterGrade + ",\nyou need to score an average greater than");
		System.out.printf("or equal to %.2f in the rest of the grade items.", avgToFinalLetterGrade);
	}
}
	}

}
