/*
 * ParseTheTweet.java
 * Author: John James 
 * Submission Date:  2/9/2023
 *
 * Purpose: A brief paragraph description of the
 * program. What does it do?
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class ParseTheTweet {

	public static void main(String[] args) {
		
		/*
		 * The code below declares a scanner that allows user input, 
		 * and declares all the variables needed for the project.
		 */
		Scanner keyboard = new Scanner(System.in);
		String tweet, type, location, detail, latitude, longitude;
		int start, finish;
		
		
		/*
		 * The code below prompts the user to enter a tweet and assigns the input
		 * to the variable "tweet". The input here will be used in later lines of code. 
		 */
		System.out.println("Enter a tweet below:");
		tweet = keyboard.nextLine();
		keyboard.close();
		
		
		/*
		 * The code below gets the index of the beginning "#" and the ending ";".
		 * Then, "substring" and "trim" are used to get the value for the variable
		 * "type". Lastly, the segment of "tweet" used to get "type" is discarded
		 * from the original string.
		 */
		start = tweet.indexOf('#');
		finish = tweet.indexOf(';');
		type = tweet.substring(start + 4, finish);
		type = type.trim();
		tweet = tweet.substring(finish + 2, tweet.length());
		tweet = tweet.trim();
		
		/*
		 * The code below repeats the above process, this time for the next variable,
		 * "detail".
		 */
		start = tweet.indexOf('#');
		finish = tweet.indexOf(';');
		detail = tweet.substring(start + 4, finish);
		detail = detail.trim();
		tweet = tweet.substring(finish + 2, tweet.length());
		tweet = tweet.trim();
		
		/*
		 * The code below repeats the process again, this time for the variable,
		 * "location".
		 */ 
		start = tweet.indexOf('#');
		finish = tweet.indexOf(';');
		location = tweet.substring(start + 4, finish);
		location = location.trim();
		tweet = tweet.substring(finish + 2, tweet.length());
		tweet = tweet.trim();
		
		/*
		 * The code below repeats the process again, this time for the variable,
		 * "latitude".
		 */
		start = tweet.indexOf('#');
		finish = tweet.indexOf(';');
		latitude = tweet.substring(start + 4, finish);
		latitude = latitude.trim();
		tweet = tweet.substring(finish + 2, tweet.length());
		tweet = tweet.trim();
		
		/*
		 * The code below repeats the process one final time for the 
		 * variable "longitude".
		 */
		start = tweet.indexOf('#');
		finish = tweet.indexOf(';');
		longitude = tweet.substring(start + 4, finish);
		longitude = longitude.trim();

		
		/*
		 * The code below prints the results of the above processes.
		 * The "type" will always be printed in capital letters.
		 * "detail" and "location" will have all of the commas in the
		 * string replaced with dashes.
		 */
		System.out.println("Type:\t\t" + type.toUpperCase());
		System.out.println("Details:\t" + detail.replace(",", "-"));
		System.out.println("Location:\t"+ location.replace(",", "-"));
		System.out.println("Latitude:\t" + latitude);
		System.out.println("Longitude:\t" + longitude);
		
	}

}
