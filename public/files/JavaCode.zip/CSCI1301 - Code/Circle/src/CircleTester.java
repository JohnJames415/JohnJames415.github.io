/*
 * CircleTester.java
 * Author:  John James
 * Submission Date:  3/29/2023
 *
 * Purpose: This tests the functionality of the methods
 * of the class Circle.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */





//*******************************************************
// CircleTester.java
//
//
//  A client to test the functionality of objects
//  of the class Circle. Use the default constructor
//  in the Circle class to create Circle objects. 
// 
//*******************************************************
public class CircleTester{
	public static final double THRESHOLD = 0.000000001;
	
	public static void main(String[] args) {
		
		Circle circle1 = new Circle();
		Circle circle2 = new Circle(); 
		circle1.setName("Circle 1");
		circle1.setX(0.0);
		circle1.setY(0.0);
		circle1.setRadius(2);
		circle2.setName("Circle 2");
		circle2.setX(2.0);
		circle2.setY(1.0);
		circle2.setRadius(1);
		System.out.println("circle1="+circle1);
		System.out.println("circle2="+circle2);
		
		// If the method setRadius is implemented correctly,
		// a call to setRadius with a negative number
		// will not change the value of the circle's radius.
		//
		circle1.setRadius(-2.0); 
		
		//This is a unit test.  It is best to have tests output pass or fail instead of just a bunch of values.
		//Notice how the double comparison is done
		if(Math.abs(2-circle1.getRadius()) < THRESHOLD)
			System.out.println("PASSED: Set Radius");
		else
			System.out.println("FAILED: Set Radius");
		
		//
		// Reset the center of circle1 (-3.0,4.0)
		//
		circle1.setX(-3.0);
		circle1.setY(4.0);
		
		
		// print circle1 characteristics (center and radius), use a statement similar 
		// to the previous println statements. Note that is not necessary to call
		//the method toString, why?
		System.out.println("circle1="+ circle1);
		
		// set the circle2 radius to 5.3
		circle2.setRadius(5.3);
		// print circle2 characteristics (center and radius), use a statement similar to the first and
		// second println statements
		System.out.println("circle2=" + circle2);
		// print circle1 diameter, area and perimeter
		System.out.println("Diameter: " + circle1.diameter() + "\nArea: " + circle1.area() + "\nPerimeter: " + circle1.perimeter());
		// print circle2 diameter, area and perimeter
		System.out.println("Diameter: " + circle2.diameter() + "\nArea: " + circle2.area() + "\nPerimeter: " + circle2.perimeter());
		// display whether circle1 is a unit circle
		if (circle1.isUnitCircle() == true) {
			System.out.println("Circle 1 is a unit circle.");
		}
		else {
			System.out.println("Circle 1 is not a unit circle.");
		}
		// display whether circle2 is a unit circle
		if (circle2.isUnitCircle() == true) {
			System.out.println("Circle 2 is a unit circle.");
		}
		else {
			System.out.println("Circle 2 is not a unit circle.");
		}
		// your additional tests should be placed below here.  Make sure to include at least 3 test cases
		// for each method you write.  It is best to write proper unit tests which print pass, fail for each
		// test instead of just dumping values to the screen.
		
		// Equals Test 1: Are equal.
		circle1.setX(5.0);
		circle1.setY(2.0);
		circle1.setRadius(3.2);
		circle2.setX(5.0);
		circle2.setY(2.0);
		circle2.setRadius(3.2);
		if ((circle1.equals(circle2)) == true)
			System.out.println("PASSED: Equals Test 1");
		else
			System.out.println("FAILED: Equals Test 1");
		
		//Equals Test 2: Unequal radii and centers.
		circle1.setX(1.0);
		circle1.setY(1.0);
		circle1.setRadius(1.8);
		circle2.setX(3.0);
		circle2.setY(6.0);
		circle2.setRadius(3.2);
		
		if ((circle1.equals(circle2)) == false)
			System.out.println("PASSED: Equals Test 2");
		else
			System.out.println("FAILED: Equals Test 2");
		
		//Equals Test 3: Same centers, different radii.
		circle1.setX(5.0);
		circle1.setY(2.0);
		circle1.setRadius(4.0);
		circle2.setX(5.0);
		circle2.setY(2.0);
		circle2.setRadius(3.2);
		if ((circle1.equals(circle2)) == false)
			System.out.println("PASSED: Equals Test 3");
		else
			System.out.println("FAILED: Equals Test 3");
		
		//Distance Test 1: Center 1: (1,1) Center 2 (4,5)
		circle1.setX(1.0);
		circle1.setY(1.0);
		circle2.setX(4.0);
		circle2.setY(5.0);
		if (circle1.distance(circle2) > 5 - THRESHOLD && (circle1.distance(circle2)) < 5 + THRESHOLD)
			System.out.println("PASSED: Distance Test 1");
		else
			System.out.println("FAILED: Distance Test 1");
		
		//Distance Test 2: Center 1: (4,8) Center: (4,5)
		circle1.setX(4.0);
		circle1.setY(8.0);
		circle2.setX(4.0);
		circle2.setY(5.0);
		if (circle1.distance(circle2) > 3 - THRESHOLD && (circle1.distance(circle2)) < 3 + THRESHOLD)
			System.out.println("PASSED: Distance Test 2");
		else
			System.out.println("FAILED: Distance Test 2");
		
		//Distance Test 3: Center 1: (4,5) Center 2: (1,1)
		circle1.setX(4.0);
		circle1.setY(5.0);
		circle2.setX(1.0);
		circle2.setY(1.0);
		if (circle1.distance(circle2) > 5 - THRESHOLD && (circle1.distance(circle2)) < 5 + THRESHOLD)
			System.out.println("PASSED: Distance Test 3");
		else
			System.out.println("FAILED: Distance Test 3");
		
		
		// isSmaller Test 1: Circle 2 is bigger
		circle1.setRadius(4.0);
		circle2.setRadius(5.0);
		if (circle1.isSmaller(circle2) == true)
			System.out.println("PASSED: isSmaller Test 1");
		else
			System.out.println("FAILED: isSmaller Test 1");
		
		// isSmaller Test 2: Equal size circles
		circle1.setRadius(2.0);
		circle2.setRadius(2.0);
		if (circle1.isSmaller(circle2) == false)
			System.out.println("PASSED: isSmaller Test 2");
		else
			System.out.println("FAILED: isSmaller Test 2");
		
		// isSmaller Test 3: Circle 1 is bigger
		circle1.setRadius(8.0);
		circle2.setRadius(6.0);
		if (circle1.isSmaller(circle2) == false)
			System.out.println("PASSED: isSmaller Test 3");
		else
			System.out.println("FAILED: isSmaller Test 3");
		
		// compareTo Test 1: Equal size circles
		circle1.setRadius(3.0);
		circle2.setRadius(3.0);
		if(circle1.compareTo(circle2) == 0)
			System.out.println("PASSED: compareTo Test 1");
		else
			System.out.println("FAILED: compareTo Test 1");
		
		// compareTo Test 2: Circle 1 is bigger
		circle1.setRadius(6.0);
		circle2.setRadius(2.0);
		if(circle1.compareTo(circle2) == 1)
			System.out.println("PASSED: compareTo Test 2");
		else
			System.out.println("FAILED: compareTo Test 2");
		
		// compareTo Test 3: Circle 2 is bigger
		circle1.setRadius(4.0);
		circle2.setRadius(5.0);
		if(circle1.compareTo(circle2) == -1)
			System.out.println("PASSED: compareTo Test 3");
		else
			System.out.println("FAILED: compareTo Test 3");
		
		// intersects Test 1: Distance < Sum of Radii
		circle1.setX(1.0);
		circle1.setY(1.0);
		circle2.setX(4.0);
		circle2.setY(5.0);
		circle1.setRadius(4.0);
		circle2.setRadius(5.0);
		if (circle1.intersects(circle2) == true)
			System.out.println("PASSED: intersects Test 1");
		else
			System.out.println("FAILED: intersects Test 1");
		
		// intersects Test 2: Distance == Sum of Radii
		circle1.setX(3.0);
		circle1.setY(2.0);
		circle2.setX(3.0);
		circle2.setY(5.0);
		circle1.setRadius(1.0);
		circle2.setRadius(2.0);
		if (circle1.intersects(circle2) == false)
			System.out.println("PASSED: intersects Test 2");
		else
			System.out.println("FAILED: intersects Test 2");
		
		// intersects Test 3: Distance > Sum of Radii
		circle1.setX(1.0);
		circle1.setY(1.0);
		circle2.setX(4.0);
		circle2.setY(5.0);
		circle1.setRadius(3.0);
		circle2.setRadius(1.0);
		if (circle1.intersects(circle2) == false)
			System.out.println("PASSED: intersects Test 3");
		else
			System.out.println("FAILED: intersects Test 3");
	}
	
}
