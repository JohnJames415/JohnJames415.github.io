/*
 * Stat.java
 * Author:  John James
 * Submission Date:  4/12/2023
 *
 * Purpose: This program provides a number of constructors and methods,
 * mainly focused around creating and manipulating double arrays. The constructors
 * allow us to create Stat objects, while the methods allow us to perform a
 * variety of operations, such as finding the minimum, maximum, and mode values
 * of an array.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

public class Stat {

	private double[] data;
	
	public Stat() { //Default Constructor for Stat	
		double[] array = new double[0];
		data = array;
	}
	public Stat(double[] d) { //Constructor for Stat when passed with a double array.
	if (d != null) {
		double[] array = new double[d.length];
		for (int i = 0; i < d.length; i++) {
			array[i] = d[i];
		}
		data = array;
	}
	else
		data = new double[0];
	}
	public Stat(float[] f) { //Constructor for Stat when passed with a float array.
	if (f != null) {
		double[] array = new double[f.length];
		for (int i = 0; i < f.length; i++) {
			array[i] = f[i];
		}
		data = array;
	}
	else
		data = new double[0];
	}
	public Stat(int[] i) { //Constructor for Stat when passed with a integer array.
	if (i != null) {
		double[] array = new double[i.length];
		for (int j = 0; j < i.length; j++) {
			array[j] = i[j];
		}
		data = array;
	}
	else
		data = new double[0];
	}

	public Stat(long[] lo) { //Constructor for Stat when passed with a long array.
	if (lo != null) {
		double[] array = new double[lo.length];
		for (int i = 0; i < lo.length; i++) {
			array[i] = lo[i];
		}
		data = array;
	}
	else
		data = new double[0];
	}
	public double[] getData() { //Creates an array with the same values as data and returns that array.
		double[] array = new double[data.length];
		for (int i = 0; i < data.length; i++) {
			array[i] = data[i];
		}
		return array;
	}
	public void setData(float[] f) { // Sets the values of data equal to that of the float array "f".
	if (f != null) {
		double[]array = new double[f.length];
		for (int i = 0; i < f.length; i++) {
			array[i] = f[i];
		}
		data = array;
	}
	else
		data = new double[0];
	}
	public void setData(double[] d) { // Sets the values of data equal to that of the double array "d".
		if (d != null) {
			double[]array = new double[d.length];
			for (int i = 0; i < d.length; i++) {
				array[i] = d[i];
			}
			data = array;
		}
		else {
			data = new double[0];
		}
	}
	public void setData(int[] i) { // Sets the values of data equal to that of the integer array "i".
	if (i != null) {
		double[]array = new double[i.length];
		for (int j = 0; j < i.length; j++) {
			array[j] = i[j];
		}
		data = array;
	}
	else
		data = new double[0];
	}
	public void setData(long[] lo) { // Sets the values of data equal to that of the long array "lo".
	if (lo != null) {
		double[]array = new double[lo.length];
		for (int i = 0; i < lo.length; i++) {
			array[i] = lo[i];
		}
		data = array;
	}
	else
		data = new double[0];
	}
	public boolean equals(Stat s) { // Uses a for loop to see if the values in the array invoked on match that of the Stat object "s".
		boolean areEqual = true;
	if (s != null && s.getData().length == this.getData().length) {
		for(int i = 0; i < s.getData().length; i++) {
			if(this.getData()[i] != s.getData()[i]) {
				areEqual = false;
			}
		}
		return areEqual;
	}
	else {
		areEqual = false;
		return areEqual;
		}
	}
	public void reset() { //Resets data to an empty array.
		data = new double [0];
	}
	public void append(int[] i) { //Adds the values of the integer array in the parameter to the array this method was invoked on.
		if (i != null) {
			double[] array = new double[i.length + data.length];
			for (int j = 0; j < data.length; j++) {
				array[j] = data[j];
			}
			for (int k = 0; k < i.length; k++) {
				array[k + data.length] = i[k];
			}
			data = array;
		}
	}
	public void append(float[] f) { //Adds the values of the float array in the parameter to the array this method was invoked on.
		
		if (f != null) {
			double[] array = new double[f.length + data.length];
			for (int i = 0; i < data.length; i++) {
				array[i] = data[i];
			}
			for (int j = 0; j < f.length; j++) {
				array[j + data.length] = f[j];
			}
			data = array;
		}
	}
	public void append(long[] lo) { //Adds the values of the long array in the parameter to the array this method was invoked on.
		if (lo != null) {
			double[] array = new double[lo.length + data.length];
			for (int i = 0; i < data.length; i++) {
				array[i] = data[i];
			}
			for (int j = 0; j < lo.length; j++) {
				array[j + data.length] = lo[j];
			}
			data = array;
		}
	}
	public void append(double[] d) { //Adds the values of the double array in the parameter to the array this method was invoked on.
		if (d != null) {
			double[] array = new double[d.length + data.length];
			for (int i = 0; i < data.length; i++) {
				array[i] = data[i];
			}
			for (int j = 0; j < d.length; j++) {
				array[j + data.length] = d[j];
			}
			data = array;
		}
	}
	public boolean isEmpty() { // If an array is empty (length of 0), this returns true
		boolean isEmpty = false;
		if (data.length == 0) {
			isEmpty = true;
		}
		return isEmpty;
	}
	public String toString() { // Prints the values of an array in brackets as a comma separated list.
		String result ="[";
		for (int i = 0; i < this.getData().length; i++) {
			result = result + this.getData()[i];
			if (i != this.getData().length -1) {
				result = result + ", ";
			}
		}
		result = result + "]";
		return result;
	}
	public double max() { //Uses a loop to sort through an array and find the biggest value.
		if (data.length != 0) {
			double max = this.getData()[0];
			for (int i = 0; i < this.getData().length; i++) {
				if (max < this.getData()[i]) {
					max = this.getData()[i];
				}
			}
			return max;
		}
		else {
			return Double.NaN;
		}
	}
	public double min() { //Uses a loop to sort through an array and find the smallest value.
		if (data.length != 0) {
			double min = this.getData()[0];
			for (int i = 0; i < this.getData().length; i++) {
				if (min > this.getData()[i]) {
					min = this.getData()[i];
				}
			}
			return min;
		}
		else {
			return Double.NaN;
		}
	}
	public double average() { //Adds all of the values of an array together and divides it by the length of the array.
		if (data.length != 0) {
			double average = 0.0;
			for (int i = 0; i < this.getData().length; i++) {
				average = average + this.getData()[i];
			}
			average = average/this.getData().length;
			return average;
		}
		else {
			return Double.NaN;
		}
	}
	public double mode() { //This finds the number that repeats most often in a loop and returns it.
		if (data.length != 0) {
			double mode = this.getData()[0]; //Value to be returned.
			double numberInQuestion; //This value gets assigned an element of the array and gets compared to all of the array's values.
			int frequency = 0;// How many times the value assessed appears in the list.
			int modeFrequency = 0; //How many times the current mode appeared in a list.
			for (int i = 0; i < this.getData().length; i++) {
				numberInQuestion = this.getData()[i];
				for (int j = 0; j <this.getData().length; j++) {
					if(this.getData()[j] == numberInQuestion) {
						frequency++;
					}	
				}
				//If frequencies of the mode and numberInQuestion are equal and they aren't the same number, then mode gets assigned this.
				if (frequency == modeFrequency && mode != numberInQuestion) {
					mode = Double.NaN;
				}
				if (frequency > modeFrequency) { // If the frequency of numberInQuestion is bigger than the mode's frequency, then the mode and it's frequency are overwritten to that of the numberInQuestion's.
					modeFrequency = frequency;
					mode = this.getData()[i];
				}
			frequency = 0; //Resets frequency to 0 reach iteration.
			}
				return mode;	
		}
		else {
			return Double.NaN;
		}
	}
	private int occursNumberOfTimes(double value) { // Finds the number of times a value occurs within an array.
		int frequency = 0;
		for (int i =0; i < data.length; i++) {
			if(data[i] == value) {
				frequency = frequency + 1;
			}
		}
		return frequency;
	}
	public double variance() { // To calculate the variance, every element in the array is subtracted from the mean, squared, and added together.
		double variance;
		double sumOfElements = 0;
		double mean = this.average();
		for (int i = 0; i < data.length; i++) {
			sumOfElements = sumOfElements + ((mean - data[i]) * (mean - data[i]));
		}
		variance = sumOfElements/data.length;
		return variance;
	}
	public double standardDeviation() { // Uses the variance method to find the standard deviation of the values in the array.
		if (data.length != 0) {
			double standardDeviation;
			double variance = this.variance();
			standardDeviation = Math.sqrt(variance);
			return standardDeviation;
		}
		else {
			return Double.NaN;
		}	
	}
}
