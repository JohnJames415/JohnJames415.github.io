
public class StatPlusTester {

	public static void main(String[] args) {

		int testCase = 5;
		
		if (testCase == 1) {
			double[] data1 = {};
			Stat stat1 = new Stat(data1);
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation());
			System.out.println("stat1 is empty = " + stat1.isEmpty() + "\n");
		}
		else if (testCase == 2) {
			double[] data1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			Stat stat1 = new Stat(data1);
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation());
			System.out.println("stat1 is empty = " + stat1.isEmpty() + "\n");
			stat1.reset();
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation());
			System.out.println("stat1 is empty = " + stat1.isEmpty() + "\n");
		}
		else if (testCase == 3) {
			float[] data1 = {10.0F,10.0F};
			Stat stat1 = new Stat(data1);
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation() + "\n");

			long[] data2 = {80L, 60L};

			stat1.append(data2);

			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation() + "\n");
		}
		else if (testCase == 4) {
			double[] data = {-5.3, 2.5, 88.9, 0, 0.0, 28, 16.5, 88.9, 109.5, -90, 88.9};
			Stat stat1 = new Stat();

			System.out.println("stat1 data = " + stat1.toString());
			stat1.append(data);

			System.out.println("stat1 has been altered.");
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation() + "\n");
		}
		else if (testCase == 5) {
			double[] data1 = {50.0, 60.0};
			float[] data2 = {70.0F, 80.0F};
			int[] data3 = {90, 100};
			long[] data4 = {100L, 110L};

			Stat stat1 = new Stat();
			System.out.println("stat1 data = " + stat1.toString());
			stat1.setData(data1);
			System.out.println("stat1 data = " + stat1.toString());
			stat1.setData(data2);
			System.out.println("stat1 data = " + stat1.toString());
			stat1.setData(data3);
			System.out.println("stat1 data = " + stat1.toString());
			stat1.setData(data4);
			System.out.println("stat1 data = " + stat1.toString());
			data1 = null;
			stat1.setData(data1);
			System.out.println("stat1 data = " + stat1.toString());
		}
		else if (testCase == 6) {
			double[] data1 = {50.0, 60.0};
			float[] data2 = {70.0F, 80.0F};
			int[] data3 = {90, 100};
			long[] data4 = {100L, 110L};
			Stat stat1 = new Stat();
			System.out.println("stat1 data = " + stat1.toString());
			stat1.append(data1);
			System.out.println("stat1 data = " + stat1.toString());
			stat1.append(data2);
			System.out.println("stat1 data = " + stat1.toString());
			stat1.append(data3);
			System.out.println("stat1 data = " + stat1.toString());
			stat1.append(data4);
			System.out.println("stat1 data = " + stat1.toString());
			data1 = null;
			stat1.append(data1);
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation() + "\n");

		}
		else if (testCase == 7) {
			double[] data1 = {10,10};
			int[] data2 = {10,10};
			Stat stat1 = new Stat(data1);
			Stat stat2 = new Stat(data2);
			Stat stat3 = new Stat();
			Stat stat4 = null;
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat2 data = " + stat2.toString());
			System.out.println("stat2 data = " + stat2.toString());
			System.out.println("stat1 equals stat2 = " + stat1.equals(stat2));
			System.out.println("stat1 equals stat3 = " + stat1.equals(stat3));
			System.out.println("stat1 equals stat4 = " + stat1.equals(stat4));
		}
		else if (testCase == 8) {
			double[] data1 = {};
			double[] data2 = { 25 };
			float[] data3 = {};
			float[] data4 = { 25 };
			int[] data5 = {};
			int[] data6 = { 50 };
			long[] data7 = {};
			long[] data8 = { 12 };
			Stat stat1 = new Stat();
			stat1.append(data1);
			stat1.append(data2);
			stat1.append(data3);
			stat1.append(data4);
			stat1.append(data5);
			stat1.append(data6);
			stat1.append(data7);
			stat1.append(data8);
			data1 = null;
			stat1.append(data1);
			System.out.println("stat1 data = " + stat1.toString());
			System.out.println("stat1 min = " + stat1.min());
			System.out.println("stat1 max = " + stat1.max());
			System.out.println("stat1 average = " + stat1.average());
			System.out.println("stat1 mode = " + stat1.mode());
			System.out.println("stat1 variance = " + stat1.variance());
			System.out.println("stat1 standard deviation = " + stat1.standardDeviation() + "\n");
		}
	}

}
