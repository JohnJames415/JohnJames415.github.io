/*
 * DrawingShapes.java
 * Author:  John James
 * Submission Date:  3/22/2023
 *
 * Purpose: This program takes the user input of shape type, length,
 * and height (if applicable), an generates a shape with all of the
 * requested properties.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class DrawingShapes {

	public static void main(String[] args) {
		String shapeType;
		int shapeLength, shapeHeight, numOfSpaces, numOfStars;
		Scanner keyboard = new Scanner(System.in); 
		
		System.out.println("Enter a shape: r t h o p");
		shapeType = keyboard.nextLine();
		
		// This section of code prints the rectangle.
		if(shapeType.equals("r")) { 
			System.out.println("Enter a length");
			shapeLength = keyboard.nextInt();
			if (shapeLength <= 1) {
				/* The boolean here assesses whether or not the user input is greater
				 * than one. If so, the loop continues. Otherwise, the program exits.
				 */
				System.out.println("Length must be greater than 1\nGoodbye!");
			}
			else {
				System.out.println("Enter a height");
				shapeHeight = keyboard.nextInt();
				if (shapeHeight <= 1) {
					// The same assessment described above is repeated here.
					System.out.println("Height must be greater than 1\nGoodbye!");
				}
				else {
					System.out.println("Below is a " + shapeLength + " by " + shapeHeight + " rectangle of *");
					/* The first loop below repeats based off the height. Meanwhile
					 * the inner loop repeats based off the length, and prints the
					 * equivalent number of stars. When the inner loop is done,
					 * a new line is created and the process is repeated until
					 * the requested height is reached.
					 */
					for (int i = 0; i < shapeHeight; i++) {
						for (int j = 0; j< shapeLength; j++) {
							System.out.print("*");
						}
						System.out.print("\n");
					}
				}
			}
		}
		// This section of code prints the triangle.
		else if (shapeType.equals("t")) {
			System.out.println("Enter a length");
			shapeLength = keyboard.nextInt();
			numOfSpaces = (shapeLength - 1);
			numOfStars = 1;
			if (shapeLength <= 1) {
				System.out.println("Length must be greater than 1\nGoodbye!");
			}
			else {
				System.out.println("Below is a triangle with two side lengths of " + shapeLength + " *");
				for (int i = 0; i < shapeLength; i++) { //This loop determines the number of spaces before the first star
					for (int j = 0; j < numOfSpaces; j++) {
						System.out.print(" ");
					}
					for (int k = 0; k < numOfStars; k++) { //This loop determines the number of stars.
						System.out.print("*");
					}
					/*The two variable assignments below change the ending condition for the
					 *two above loops. This allows for the program to gradually increase
					 *the base of the triangle as it's printing. These statements appear
					 *several times throughout this program, and most of them are marked as
					 * "correction statements".
					 */
					numOfStars = numOfStars + 2; 
					numOfSpaces = numOfSpaces - 1;
					System.out.print("\n");
				}
			}
		}
		else if (shapeType.equals("h")) { //This section of code prints the hexagon.
			System.out.println("Enter a length");
			shapeLength = keyboard.nextInt();
			numOfSpaces = (shapeLength - 1);
			numOfStars = shapeLength;
			if (shapeLength <=1) {
				System.out.println("Length must be greater than 1\nGoodbye!");
			}
			else {
				System.out.println("Below is a hexagon with side lengths of " + shapeLength + " *");
				for (int i = 0; i < shapeLength; i++) { //This loop generates the top half of the hexagon.
					for (int j = 0; j < numOfSpaces; j++) { //This loop generates the appropriate number of spaces.
						System.out.print(" ");
					}
					for (int k = 0; k < numOfStars; k++) { // This loop generates the appropriate number of stars.
						System.out.print("*");
					}
					// These two statements below are correction statements similar to those of the triangle.
					numOfStars = numOfStars + 2; 
					numOfSpaces = numOfSpaces - 1;
					
					System.out.print("\n");
				}
				numOfStars = (numOfStars - 2);
				numOfSpaces = (numOfSpaces + 1);
				for (int l = shapeLength; l >= 1; l--) { //This loop controls the bottom half of the hexagon
					for (int m = numOfSpaces; !(m <= 0); m--) { // This loop generates the appropriate number of spaces.
						System.out.print(" ");
					}
					/*The below loop generates the correct number of stars needed for the hexagon.
					 *The controlling boolean acts as a corrector, preventing the stars from printing
					 *on the first run through (to avoid printing the longest middle line twice).
					 */
					if (l != shapeLength) {
						for (int n = numOfStars; !(n <=0); n--) {
							System.out.print("*");
						}
					}
					// The below statements are correction statements.
					numOfSpaces = (numOfSpaces + 1);
					numOfStars = (numOfStars - 2);
					
					if (l != shapeLength) {
						System.out.print("\n");
					}
				}
			}
				
		}
		else if (shapeType.equals("o")) { // This section of code prints the octagon.
			System.out.println("Enter a length");
			shapeLength = keyboard.nextInt();
			numOfSpaces = (shapeLength - 1);
			numOfStars = shapeLength;
			if (shapeLength <=1) {
				System.out.println("Length must be greater than 1\nGoodbye!");
			}
			else {
				System.out.println("Below is an octagon with side lengths of " + shapeLength + " *");
				for (int i = 0; i < shapeLength; i++) { // This loop generates the top section of the octagon. It works similar to that of the hexagon's top loop.
					for (int j = 0; j < numOfSpaces; j++) { //Generates the correct number of spaces.
						System.out.print(" ");
					}
					for (int k = 0; k < numOfStars; k++) { // Generates the correct number of stars.
						System.out.print("*");
					}
					//Correction Statements
					numOfStars = numOfStars + 2;
					numOfSpaces = numOfSpaces - 1;
					
					System.out.print("\n");
				}
				for (int p = 0; p < shapeLength-2; p++) { //This loop generates the middle of the octagon. It works similar to that of the rectangle's loop.
					for (int q = 0; q < numOfStars-2; q++) {
						System.out.print("*");
					}
					System.out.print("\n");
				}
				for (int l = shapeLength; l >= 0; l--) { // This loop generates the bottom part of the octagon. It works similar to that of the hexagon's bottom loop.
					for (int m = numOfSpaces; !(m <= 0); m--) {
						System.out.print(" ");
					}
					if (l != shapeLength) {
						for (int n = numOfStars; !(n <=0); n--) {
							System.out.print("*");
						}
					}
					//Correction Statements
					numOfSpaces = (numOfSpaces + 1);
					numOfStars = (numOfStars - 2);
					
					if (l != shapeLength) {
						System.out.print("\n");
					}
				}
			}
				
		}
		else if (shapeType.equals("p")) { // This section of code prints the pentagon.
			System.out.println("Enter a length");
			shapeLength = keyboard.nextInt();
			numOfSpaces = (shapeLength - 1);
			numOfStars = 1;
			if (shapeLength <= 1) {
				System.out.println("Length must be greater than 1\nGoodbye!");
			}
			else {
				System.out.println("Below is a pentagon with 4 side lengths of " + shapeLength + " *");
				for (int i = 0; i < shapeLength; i++) { // This loop generates the top half of the pentagon, and works similar to the triangle's loop.
					for (int j = 0; j < numOfSpaces; j++) { // This loop generates the appropriate number of spaces.
						System.out.print(" ");
					}
					for (int k = 0; k < numOfStars; k++) { // This loop generates the appropriate number of stars.
						System.out.print("*");
					}
					numOfStars = numOfStars + 2;
					numOfSpaces = numOfSpaces - 1;
					System.out.print("\n");
				}
				//Correction Statements
				numOfStars = (numOfStars - 2);
				numOfSpaces = (numOfSpaces + 1);
				for (int i = 0; i < shapeLength - 1; i++) { // This loop generates the bottom half of the pentagon, and works similar to that of the rectangle's loop.
					for (int j = 0; j < numOfStars; j++) {
						System.out.print("*");
					}
					System.out.print("\n");
				}
			}
		}
		else { // In the event the user does not input a valid shape, the program will output an error and close.
			System.out.println("Invalid shape\nGoodbye!");
		}
		keyboard.close();
	}

}
