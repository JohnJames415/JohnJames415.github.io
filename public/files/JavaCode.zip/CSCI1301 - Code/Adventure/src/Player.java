/*
 * Adventure.java
 * Author:  John James
 * Submission Date:  4/10/23
 *
 * Purpose: This program contains all of the instance variables and methods needed
 * for player objects in Adventure.java.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */
public class Player {

	private int xCoordinate;
	private int yCoordinate;
	private Key playerKey = null;
	private Lamp playerLamp = null;
	private boolean isPlayerAlive = true;
	
	public Player() {
		xCoordinate = 0;
		yCoordinate = 0;
	}
	public void moveNorth() { //Moves player north
		xCoordinate = xCoordinate -1;
	}
	public void moveSouth() { //Moves player south
		xCoordinate = xCoordinate +1;
	}
	public void moveEast() { //Moves player east
		yCoordinate = yCoordinate +1;
	}
	public void moveWest() { //Moves player west
		yCoordinate = yCoordinate -1;
	}
	public int getX() { // Retuns player x value
		return xCoordinate;
	}	
	public int getY() { // Returns player y value
		return yCoordinate;
	}
	public void killPlayer() { //Kills the player if they stumble into a grue
		isPlayerAlive = false;
	}
	public boolean isPlayerAlive() { //Checks if the player is alive
		return isPlayerAlive;
	}
	public void setPlayerKey(Key thisKey) { //Allows player to get the key
		playerKey = thisKey;
	}
	public void setPlayerLamp(Lamp thisLamp) { //Allows player to get the lamp
		playerLamp = thisLamp;
	}
	public boolean playerHasLamp() { // Checks if the player has the lamp
		if(playerLamp == null) {
			return false;
		}
		else {
			return true;
		}
	}
	public boolean playerHasKey() { // Checks if the player has the key
		if(playerKey == null) {
			return false;
		}
		else {
			return true;
		}
	}
	public Key playerKey() { //Returns the player's key
		return playerKey;
	}
	public Lamp playerLamp() { //Returns the player's lamp
		return playerLamp;
	}
	
}
