/*
 * Adventure.java
 * Author:  John James
 * Submission Date:  4/10/23
 *
 * Purpose: This program culminates the Player class, Chest class, Room class, Map
 * class, Key class, and Lamp class and makes an interactive fiction game.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class Adventure {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		Player mainCharacter = new Player();
		Map playspace = new Map();
		
		String command;
		Boolean isTreasureFound = false;
		
		System.out.println("Welcome to UGA Adventures: Episode 1\nThe adventure of the Cave of Redundancy Adventure\nBy: John James\n");
		System.out.println(playspace.getRoom(0, 0).getDescription()); // Prints starting room info.
		
		while (mainCharacter.isPlayerAlive() && isTreasureFound == false) {  //Overarching loop controlling the game.
			command = keyboard.nextLine(); //Stores user command
			
			if (command.equalsIgnoreCase("get lamp")) { // Get lamp command gives the player the lamp should it be in the room.
				if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getLamp() != null) {
					System.out.println("OK");
					mainCharacter.setPlayerLamp(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getLamp());
					playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).clearLamp();
				}
				else { //If not lamp is in the current room, this will print.
					System.out.println("No lamp present");
				}
			}
			else if (command.equalsIgnoreCase("light lamp")) { //If the player has the lamp, this will light it.
				if(mainCharacter.playerHasLamp() == false) {
					System.out.println("You don't have the lamp to light"); //Prints if no lamp is present
				} 
				else if ((mainCharacter.playerLamp().isLampLit() == false)) {
					System.out.println("OK");
					mainCharacter.playerLamp().lightLamp(); //Lights lamp
				} 
				else {
					System.out.println("Lamp is already lit!"); // Prints if the lamp is already lit.
				}
			}
			/* The next four commands are the movement commands. If the user is in a dark room,
			 * with no lamp or an unlit lamp, and they move, they will get eaten and the game is over. 
			 * Otherwise they move the desired direction. If the new room is dark, it will print out
			 * that it is dark. If not, then it will print out the room description.
			 * 
			 */
			else if (command.equalsIgnoreCase("north")) { 
				if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || mainCharacter.playerLamp().isLampLit() == false)) {
					System.out.println("You have stumbled into a passing grue, and have been eaten");
					mainCharacter.killPlayer();
				}
				else if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoNorth()) {
					mainCharacter.moveNorth();
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || mainCharacter.playerLamp().isLampLit() == false)) {
						System.out.println("It is pitch black, you can't see anything. You may be eaten by a grue!");
					}
					else {
						System.out.println(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getDescription());
					}
					
				}
				else {
					System.out.println("You can't move north!");
				}
			}
			else if (command.equalsIgnoreCase("south")) {
				if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || mainCharacter.playerLamp().isLampLit() == false)) {
					System.out.println("You have stumbled into a passing grue, and have been eaten");
					mainCharacter.killPlayer();
				}
				else if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoSouth()) {
					mainCharacter.moveSouth();
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || mainCharacter.playerLamp().isLampLit() == false)) {
						System.out.println("It is pitch black, you can't see anything. You may be eaten by a grue!");
					}
					else {
						System.out.println(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getDescription());
					}
					
				}
				else {
					System.out.println("You can't move south!");
				}
			}
			else if (command.equalsIgnoreCase("east")) {
				if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || (mainCharacter.playerLamp().isLampLit() == false))) {
					System.out.println("You have stumbled into a passing grue, and have been eaten");
					mainCharacter.killPlayer();
				}
				else if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoEast()) {
					mainCharacter.moveEast();
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || (mainCharacter.playerLamp().isLampLit() == false))) {
						System.out.println("It is pitch black, you can't see anything. You may be eaten by a grue!");
					}
					else {
						System.out.println(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getDescription());
					}
					
				}
				else {
					System.out.println("You can't move east!");
				}
			}
			else if (command.equalsIgnoreCase("west")) {
				if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || mainCharacter.playerLamp().isLampLit() == false)) {
					System.out.println("You have stumbled into a passing grue, and have been eaten");
					mainCharacter.killPlayer();
				}
				else if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoWest()) {
					mainCharacter.moveWest();
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || mainCharacter.playerLamp().isLampLit() == false)) {
						System.out.println("It is pitch black, you can't see anything. You may be eaten by a grue!");
					}
					else {
						System.out.println(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getDescription());
					}
					
				}
				else {
					System.out.println("You can't move west!");
				}
			}
			else if (command.equalsIgnoreCase("look")) { //Prints out the room description. If either the chest key or lamp are present, then a statement will print notifying the player. It will also print all available exits.
				if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).isDark() && ((mainCharacter.playerHasLamp() == false) || (mainCharacter.playerLamp().isLampLit() == false))) {
					System.out.println("It is pitch black, you can't see anything. You may be eaten by a grue!"); //If the room is dark, and the user has no lamp or their lamp isn't on, this will print instead of the room description.
				}
				else {
					System.out.println(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getDescription());
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getLamp() != null) {
						System.out.print("There is an old oil lamp that was made long ago here.\n");
					}
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getKey() != null) {
						System.out.print("You see the outline of a key on a dusty shelf that's covered in dust.\n");
					}
					if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getKey() != null) {
						System.out.print("There is a large, wooden, massive, oaken chest here with the word \"CHEST\" carved into it.\n");
					}
					System.out.print("Exits are: ");
					if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoNorth()) {
						System.out.print("north\n");
					}
					if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoWest()) {
						System.out.print("west\n");
					}
					if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoEast()) {
						System.out.print("east\n");
					}
					if(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).canGoSouth()) {
						System.out.print("south\n");
					}
				}
			}
			else if (command.equalsIgnoreCase("get key")) { //Allows the player to get the key
				if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getKey() != null) {
					System.out.println("OK");
					mainCharacter.setPlayerKey(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getKey());
					playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).clearKey();
				}
				else { // If the key is not present, this will print.
					System.out.println("No key present");
				}
			}
			else if (command.equalsIgnoreCase("unlock chest")) { // If the player has the key and the chest is present, the user will unlock the chest.
				if (mainCharacter.playerHasKey() && (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest() != null)) {
					System.out.println("OK");
					(mainCharacter.playerKey()).use(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest());
				}
				else if (mainCharacter.playerHasKey() == false) { //Prints if player doesn't have key
					System.out.println("Need a key to do any unlocking!");
				}
				else if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest() == null) {
					System.out.println("No chest present"); //Prints if there's no chest in the current room
				}
			}
			else if (command.equalsIgnoreCase("open chest")) { // If the chest is unlocked and present within the room, the player will open it.
				if((playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest() != null) && (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest().isLocked() == false)) {
					System.out.println(playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest().getContents());
					isTreasureFound = true;
				}
				else if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest().isLocked() == true) {
					System.out.println("The chest is locked"); //Prints if the user has yet to unlock the chest
				}
				else if (playspace.getRoom(mainCharacter.getX(), mainCharacter.getY()).getChest() == null) {
					System.out.println("No chest present"); //Prints if there is no chest in the current room
				}
			}
			else { // If the user inputs something that isn't one of the above cases, then this will print.
				System.out.println("Im sorry I don't know how to do that. Please enter another command.");
			}
		}
		keyboard.close();
	}
}
