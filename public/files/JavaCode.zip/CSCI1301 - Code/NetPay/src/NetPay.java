/*
 * NetPay.java
 * Author: John James
 * Submission Date:  1/25/2023
 *
 * Purpose: This program intends to calculate one's net pay
 * when provided the number of hours they work each week.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class NetPay {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner (System.in);
		int numberOfHours;
		//This code provides our instance of Scanner and declares the variable numberOfHours.
		
		System.out.print("Hours per Week:\t\t");
		numberOfHours = keyboard.nextInt();
		keyboard.close();
		// This code is what prompts the user to enter the number of hours they work per week.
		
		double FEDERAL_TAX_PERCENT = 10.00;
		double STATE_TAX_PERCENT = 4.5;
		double SS_PERCENT = 6.2;
		double MEDICARE_PERCENT = 1.45;
		double PAY_PER_HOUR = 7.25;
		// The code above declares variables that contain the percents needed for future calculations.
		
		double grossPay = numberOfHours * PAY_PER_HOUR;
		double federalDeductions = grossPay * FEDERAL_TAX_PERCENT * .01;
		double stateDeductions = grossPay * STATE_TAX_PERCENT * .01;
		double socialDeductions = grossPay * SS_PERCENT * .01;
		double medicareDeductions = grossPay * MEDICARE_PERCENT *.01;
		double netPay = grossPay - federalDeductions - stateDeductions - socialDeductions - medicareDeductions;
		//The code above declares variables for the deductions section, using calculations with previous variables to assign them a value.
		
		System.out.println("Gross Pay: \t\t" + grossPay);
		System.out.println("Net Pay: \t\t" + netPay);
		System.out.println(" ");
		System.out.println("Deductions");
		System.out.println("Federal: \t\t" + federalDeductions);
		System.out.println("State: \t\t\t" + stateDeductions);
		System.out.println("Social Security: \t" + socialDeductions);
		System.out.println("Medicare: \t\t" + medicareDeductions);
		// This code prints the results of the calculations in the previous section.
	}

}
