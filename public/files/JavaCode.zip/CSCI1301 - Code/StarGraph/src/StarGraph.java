/*
 * StarGraph.java
 * Author:  John James
 * Submission Date:  3/20/2023
 *
 * Purpose: This program takes user input of a number of values to process,
 * a minimum value for x, and a value to increment by, and using loops, it
 * outputs a table for x & y, as well as a graph that displays the data.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */
import java.util.Scanner;

public class StarGraph {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in); //Allows for user input.
		int sizeOfArray; //The length of an array
		double xMin; // The minimum (or first) x-value that is processed.
		double xIncrement; // The amount that x increases after each run.
		
		System.out.print("Please enter the number of x values to process: ");
		sizeOfArray = keyboard.nextInt();
		
	/* The if-else below checks the value of sizeOfArray. If the number is less than
	 * or equal to 0, the program presents an error message and closes. Otherwise,
	 * the program will continue.
	 */
		if (sizeOfArray <= 0) {
			System.out.println("The number of x values must be an integer greater than 0.");
			System.exit(0);
		} 
		else {
			double[] xArray = new double[sizeOfArray];
			double[] yArray = new double[sizeOfArray];
			System.out.print("Enter a minimum value for x: ");
			xMin = keyboard.nextDouble();
			System.out.print("Enter the amount to increment x: ");
			xIncrement = keyboard.nextDouble();
			keyboard.close();
			if (xIncrement <= 0) { //Same process as the first if-else.
				System.out.println("The increment must be a decimal number greater than 0.");
				System.exit(0);
			} 
			else {
				/*The code below assigns a value to the first slot of the x and y arrays.
				 * Each additional slot in the array is assigned using a for loop. All
				 * of these results are printed to the console.
				 */
				System.out.println("\nValues");
				xArray[0] = xMin;
				yArray[0] = 20.0 * Math.abs(Math.sin(xArray[0]));
				System.out.printf("x: %.3f", xArray[0]);
				System.out.printf(", y: %.3f\n", yArray[0]);
				for (int i = 1; i < sizeOfArray; i++) {
					xArray[i] = xMin + xIncrement;
					yArray[i] = 20.0 * Math.abs(Math.sin(xArray[i]));
					xMin = xMin + xIncrement;
					System.out.printf("x: %.3f", xArray[i]);
					System.out.printf(", y: %.3f\n", yArray[i]);
				}
				/*The loop below generates the graph. For each value in yArray, a ":"
				 * is added. Then, in front of each colon, a dot is added that corresponds
				 * to the current number in yArray (cast as an int) being indexed through.
				 */
				System.out.println("\nGraph");
				for (int i = 0; i < sizeOfArray; i++) {
					System.out.print(":");
					for (int j = 0; j < (int)yArray[i]; j++) {
						System.out.print("*");
					}
				System.out.print("\n");
				}
			}	
		}
	}

}
