/*
 * StringFun.java
 * Author:  John James
 * Submission Date:  3/15/2023
 *
 * Purpose: This program allows the user to input a string
 * and modify it using a various commands.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class StringFun {

	public static void main(String[] args) {
		// The code below creates all of the necessary variables for the project.
		Scanner keyboard = new Scanner(System.in);
		String mainString, userCommand, newString = "";
		char charToReplace = 'a', charReplacer = 'a';
		boolean isCharNotReplaced = true, isCharNotRemoved = true, isProgramRunning = true;
		String remainderString = "";
		char characterToRemove;
		int positionOfLetterToRemove;
		boolean hasNotBeenManipulated = true;
		String baseString =""; //nextLineCorrection is intentionally left unused.

		
// The code below prompts the user to input starting string.
		System.out.println("Enter the string to be manipulated"); 
		mainString = keyboard.nextLine();
		 
		
while (isProgramRunning) { // This is a loop that never ends. The main way to exit the loop is using the "quit" command.
		System.out.println("Enter your command (reverse, replace first, replace last, remove all, remove, quit)");
		userCommand = keyboard.nextLine();
		 
		 if (userCommand.equalsIgnoreCase("reverse")) { //REVERSE COMMAND
			 //The code below uses a loop to reprint the main string backwards.
			 for (int i = 0; i < mainString.length(); i++) 
			 {
		 		 newString = newString + mainString.charAt(mainString.length() - (1 + i));
		 		 hasNotBeenManipulated = false;
		 		 /* Boolean Variables such as "hasNotBeenManipulated" assist in the process
		 		  * of resetting the loop after every command.
		 		  */
			 }
			//The below code prints the results to console
		 	System.out.println("The new sentence is: "+ newString); 
		 }
		 else if (userCommand.equalsIgnoreCase("replace first"))  //REPLACE FIRST COMMAND
		 {
			 System.out.println("Enter the character to replace"); 
			 charToReplace = keyboard.nextLine().charAt(0);
			 
			 System.out.println("Enter the new character");
			 charReplacer = keyboard.nextLine().charAt(0);
			 
			 /*The code below uses a loop to sort through and split mainString, 
			  * remove the letter of choice to be replaced, inserts the new letter 
			  * in its place, and puts remaining pieces of mainString back together.
			  */
			 for (int i = 0; (i < mainString.length() && isCharNotReplaced); i++)
				 if (mainString.charAt(i) == charToReplace) {
					 isCharNotReplaced = false;
					 remainderString = mainString.substring(i + 1, mainString.length());
					 newString = mainString.substring(0, i);
					 newString = newString + charReplacer;
					 newString = newString.concat(remainderString);
				 }
			 
			 if (isCharNotReplaced == true)
				 System.out.println("The letter was not found in the word");
			 else
				 System.out.println("The new sentence is: " + newString);
			 
		 }
		 else if (userCommand.equalsIgnoreCase("replace last")) // REPLACE LAST COMMAND
		/* This works the exact same as the prior command, but the 
		 * controlling expression in the for loop is slightly different.
		 */
		 {
			 System.out.println("Enter the character to replace");
			 charToReplace = keyboard.nextLine().charAt(0);
			 
			 System.out.println("Enter the new character");
			 charReplacer = keyboard.nextLine().charAt(0);
			 
			 for (int i = 0; i < mainString.length(); i++)
				 if (mainString.charAt(i) == charToReplace) {
					 isCharNotReplaced = false;
					 remainderString = mainString.substring(i + 1, mainString.length());
					 newString = mainString.substring(0, i);
					 newString = newString + charReplacer;
					 newString = newString.concat(remainderString);
				 }
			 
			 if (isCharNotReplaced == true)
				 System.out.println("The letter was not found in the word");
			 else
				 System.out.println("The new sentence is: " + newString);
		 }
		 else if (userCommand.equalsIgnoreCase("remove all")) //REMOVE ALL COMMAND
		/* The code below uses a for loop that reprints mainString, excluding the
		 * letters that are requested to be removed.
		 */
		 {
			 System.out.println("Enter the character to remove");
			 characterToRemove = keyboard.nextLine().charAt(0);
			 for (int i = 0; i < mainString.length(); i++) 
			 {
				 if(mainString.charAt(i) != characterToRemove) 
				 {
					 isCharNotRemoved = false;
					 newString = newString + mainString.charAt(i);
				 }
			 }
			 
			 if (isCharNotRemoved == true)
				 System.out.println("The letter was not found in the word");
			 else
				 System.out.println("The new sentence is: " + newString);
			 
			 if (isCharNotRemoved == false)
			 {
				 mainString = newString;
				 newString = "";	
			 } 
		 }
		 else if (userCommand.equalsIgnoreCase("remove")) //REMOVE COMMAND
		/* This loop cycles through mainString and detects when the user selected
		 * letter appears. Once it appears, j, a variable local to the loop, increments by 1.
		 * When j is equal to the same value of the user-selected position, it removes that letter.
		 * However, if j ever becomes greater than the user selected position, then
		 * that indicates that the value does not exist.
		 */
		 {
			 System.out.println("Enter the character to remove");
			 characterToRemove = keyboard.nextLine().charAt(0);
			 
			 System.out.println("Enter the " + characterToRemove + " you would like to remove (Not the index - 1 = 1st, 2 = 2nd, etc.):");
			 positionOfLetterToRemove = keyboard.nextInt();
			 keyboard.nextLine();
			 baseString = mainString;
			 for (int i = 0, j = 0; i < mainString.length(); i++) 
			 {
				 if(mainString.charAt(i) == characterToRemove)
				 {
					j++;
				 	if (j == positionOfLetterToRemove)
				 		newString = mainString.substring(0, i).concat(mainString.substring((i+1), mainString.length()));
				 		isCharNotRemoved = false;
				 }
				 if (j < positionOfLetterToRemove && isCharNotRemoved == false)
					 isCharNotRemoved = true;
			 }
			 if (isCharNotRemoved == true) {
				System.out.println("Error: The letter your are trying to remove does not exist");
			 	mainString = baseString;
			 	newString ="";
			 }
			 else {
				System.out.println("The new sentence is: " + newString);
			 	mainString = newString;
				newString = "";	
			 }
		 }
		 else if (userCommand.equalsIgnoreCase("quit")) // QUIT COMMAND
			 System.exit(0);
		 else //This condition below will trigger when an unknown command is input.
			 System.out.println("Command invalid. Try again");
		 
		 
		 /* The rest of the code below (except for "keyboard.close();") is used to reset 
		  * the main loop controlling the whole program.
		  */
		 if (isCharNotReplaced == false) {
			 mainString = newString;
		 	 newString = "";
		 } 
		 if (hasNotBeenManipulated == false) {
			 mainString = newString;
		  	 newString = "";
		 }
		 
		 
		 isCharNotRemoved = true;
		 isCharNotReplaced = true;
		 hasNotBeenManipulated = true;
}

keyboard.close();
	}

}
