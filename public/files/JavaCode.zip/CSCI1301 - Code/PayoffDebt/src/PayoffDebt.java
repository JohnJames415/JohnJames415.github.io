/*
 * PayoffDebt.java
 * Author: John James
 * Submission Date:  2/1/2023
 *
 * Purpose: This program takes the user inputs of their principal,
 * annual interest rate, and the amount of their monthly payment,
 * and then outputs the number of months needed to pay off their debt,
 * as well as the total amount paid, amount of interest paid, and
 * the amount overpaid.
 * 
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this project is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */


import java.util.Scanner;
public class PayoffDebt {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		double principal, annualInterestRate, monthlyPayment;
		double equationResult1, equationResult2, monthsNeededToPayOffRaw;
		double totalAmountPaid, totalInterestPaid, overPayment;
		int monthsNeededToPayOffCeil;
/*
 * Here, line 34 allows the program to read user inputs. The following lines
 * of code create all of the variables needed for the project. The 
 * first set of variables are what the user is asked to enter. The
 * second set of variables are variables used in calculations to 
 * figure out the number of months needed to pay off the users debt.
 * The third set of variables and "monthsNeededToPayOffCeil" are used to calculate
 * and display the values for "Total Amount Paid:", "Total Interest 
 * Paid:" and "Overpayment:"
 */
		
		System.out.print("Principal:\t\t\t");
		principal = keyboard.nextDouble();
		System.out.print("Annual Interest Rate (%):\t");
		annualInterestRate = keyboard.nextDouble();
		System.out.print("Monthly Payment:\t\t");
		monthlyPayment = keyboard.nextDouble();
		keyboard.close();
// This prompts the user to enter their information.
		
		equationResult1 = Math.log(monthlyPayment - annualInterestRate/1200.00 * principal);
		equationResult2 = Math.log(monthlyPayment) - equationResult1;
		monthsNeededToPayOffRaw = equationResult2/Math.log(annualInterestRate/1200.00 + 1.0);
		monthsNeededToPayOffCeil = (int)Math.ceil(monthsNeededToPayOffRaw);
// This calculates the number of months needed to pay off the debt.
		
		totalAmountPaid = monthlyPayment * monthsNeededToPayOffCeil;
		totalInterestPaid = totalAmountPaid - principal;
// This calculates the values for "Total Amount Paid:" and "Total Interest Paid:"

		
//Computation of overPayment: Monthly Payment * Months Needed To Pay Off Debt (Rounded Up) - Monthly Payment * Months Needed To Pay Off Debt (Not Rounded Up)
		overPayment = (monthlyPayment * monthsNeededToPayOffCeil) - (monthlyPayment * monthsNeededToPayOffRaw);
		
		System.out.println("\nMonths Needed To Pay Off:\t"+ monthsNeededToPayOffCeil);
		System.out.printf("Total Amount Paid:\t\t$%.2f\n",totalAmountPaid);
		System.out.printf("Total Interest Paid:\t\t$%.2f\n",totalInterestPaid);
		System.out.printf("Overpayment:\t\t\t$%.2f\n",overPayment);
//This takes the calculated values and prints them to the console.
	}

}
