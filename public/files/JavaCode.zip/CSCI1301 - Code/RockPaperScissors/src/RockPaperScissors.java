/*
 * RockPaperScissors.java
 * Author:  John James
 * Submission Date: 2/27/2023
 *
 * Purpose: This program allows a user to play rock, paper, scissors
 * against a computer. The user will provide a number of wins one must
 * reach to end the play session, and they will play until
 * one of them hits that number of wins.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

import java.util.Scanner;
public class RockPaperScissors {

	public static void main(String[] args) {
		
/* The code below declares all variables necessary for the project
 * and declares the scanner for user input. The variable nextLineCorrection is
 * intentionally "unused", as its sole purpose is to assist in getting user input
 * for playerMove using "nextLine".
 */
		String computerMove = "null";
		String playerMove = "null";
		int numberOfWinsToEnd;
		int computerWins = 0;
		int playerWins = 0;
		String nextLineCorrection;
		boolean isGameInProgress = true;
		boolean isPlayerMoveInvalid = true;
		Scanner keyboard = new Scanner(System.in);

// The user is prompted to enter a score they want to play to.
System.out.print("Points to win: ");
numberOfWinsToEnd = keyboard.nextInt();
nextLineCorrection = keyboard.nextLine();


// This loop continues until either the computer or user reaches the previously entered score.
while (isGameInProgress) {

	/* The below loop prompts the user to enter either "rock" "paper" or "scissors"
	 * If it equals one of those three values (ignoring capitalization and outside spaces), the loop breaks.
	 * If not, it will prompt the user again.
	 */
	while (isPlayerMoveInvalid) {
		System.out.print("Rock, paper, or scissors? ");
		playerMove = keyboard.nextLine();
		playerMove = playerMove.trim();
		if (playerMove.equalsIgnoreCase("paper") || playerMove.equalsIgnoreCase("rock") || playerMove.equalsIgnoreCase("scissors"))
			isPlayerMoveInvalid = false;
		else
			isPlayerMoveInvalid = true;
	} 

	/* The below code allows the computer to get its answer. 
	 * Using rock, paper, scissor rules, the two answers are then compared.
	 * Lastly, the computer will tell the user if they won, lost, or tied,
	 * as well as read off the current score. The user is then prompted to enter
	 * another answer if the win limit has not been reached.
	 */
	computerMove = ComputerOpponent.getMove();
	if (playerMove.equalsIgnoreCase("rock") && computerMove.equalsIgnoreCase("paper")) {
		computerWins++;
		System.out.print(", so you lose. (" + playerWins + "-" + computerWins + ")\n");
	} else if (playerMove.equalsIgnoreCase("rock") && computerMove.equalsIgnoreCase("scissors")) {
		playerWins++;
		System.out.print(", so you win! (" + playerWins + "-" + computerWins + ")\n");
	} else if (playerMove.equalsIgnoreCase("paper") && computerMove.equalsIgnoreCase("rock")) {
		playerWins++;
		System.out.print(", so you win! (" + playerWins + "-" + computerWins + ")\n");
	} else if (playerMove.equalsIgnoreCase("paper") && computerMove.equalsIgnoreCase("scissors")) {
		computerWins++;
		System.out.print(", so you lose. (" + playerWins + "-" + computerWins + ")\n");
	} else if (playerMove.equalsIgnoreCase("scissors") && computerMove.equalsIgnoreCase("paper")) {
		playerWins++;
		System.out.print(", so you win! (" + playerWins + "-" + computerWins + ")\n");
	} else if (playerMove.equalsIgnoreCase("scissors") && computerMove.equalsIgnoreCase("rock")) {
		computerWins++;
		System.out.print(", so you lose. (" + playerWins + "-" + computerWins + ")\n");
	} else
		System.out.print(", so it's a tie. (" + playerWins + "-" + computerWins + ")\n");
		
	
	/* The conditional below evaluates whether or not either the player or computer has
	 * won by comparing their number of wins to the value initially entered by the user.
	 * The console will display different messages depending on which player won.
	 */
	if ((playerWins == numberOfWinsToEnd)) {
		isGameInProgress = false;
		System.out.println("Congratulations! You won!");
	} else if (computerWins == numberOfWinsToEnd) {
		isGameInProgress = false;
		System.out.println("Sorry, you lost. Better luck next time!");
	}	
// This variable is set back to true so that the computer is able to prompt the user for another answer after each round.
isPlayerMoveInvalid = true;

}	

keyboard.close();


	}
}
