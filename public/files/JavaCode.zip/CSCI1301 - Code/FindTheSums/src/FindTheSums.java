/*
 * FindTheSums.java
 * Author:  John James
 * Submission Date:  4/20/2023
 *
 * Purpose: This class provides the methods needed to assess number arrays
 * and find a sum of numbers within a number array equal to a provided value.
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this project is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */

public class FindTheSums {

public static String arrayToString(int[][] a) { // Prints the array provided as a string.
	String arrayAsString = "";
	for (int m = 0; m < a.length; m++) {
		for (int n = 0; n < a[0].length; n++) {
			arrayAsString = arrayAsString + a[m][n];
			if (n != a[0].length- 1) {
				arrayAsString = arrayAsString + " ";
			}
		}
		if(m != a.length-1)
		arrayAsString = arrayAsString + "\n";
	}
	return arrayAsString;
}
public static int[][] horizontalSums(int[][] a, int sumToFind) {
	int sum = 0; 
	int[][] b = new int[a.length][a[0].length];

	// This assigns all elements of b to 0.
	for (int row = 0; row < a.length; row++) {
		for (int column = 0; column < a[row].length; column++) {
			b[row][column] = 0;
		}
	}
	// This loop gets the collective sum of the elements
	for (int row = 0; row < a.length; row++) { // This loop gets the collective sum of the elements
		for (int startIndex = 0; startIndex < a[row].length - 1; startIndex++) {
			for (int endIndex = startIndex; endIndex < a[startIndex].length && sum < sumToFind; endIndex++) {
				sum += a[row][endIndex];
				
				// If the sum is matched, it overwrites the respective values of 0 with the elements of a that added to the sum.
				if (sum == sumToFind) { 
					for (int i = startIndex; i <= endIndex; i++) {
						b[row][i] = a[row][i];
					}
					sum = 0; 
				}
			}
			sum =0;
		}
	}
	return b;
}
public static int[][] verticalSums(int[][] a, int sumToFind) {
	int sum = 0;
	int[][] b = new int[a.length][a[0].length];

	// This assigns all elements of b to 0.
	for (int row = 0; row < a.length; row++) {
		for (int column = 0; column < a[row].length; column++) {
			b[row][column] = 0;
		}
	}
	// This loop gets the collective sum of the elements. 
	// It works the same as that in horizontal sums, but it is tweaked to work on a per column basis (as opposed to per row).
	for (int column = 0; column < a[0].length; column++) {
		for (int startIndex = 0; startIndex < a.length; startIndex++) {
			for (int endIndex = startIndex; endIndex < a.length && sum < sumToFind; endIndex++) {
				sum += a[endIndex][column];

				if (sum == sumToFind) {
					for (int i = startIndex; i <= endIndex; i++) {
						b[i][column] = a[i][column];
					}
					sum = 0;
				}
			}
			sum = 0;
		}
	}
	return b;
}

}
